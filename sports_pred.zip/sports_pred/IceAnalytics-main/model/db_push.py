from scraper_functions import *

PROJECTION_YEAR = 2025
push_to_supabase("team_projections", PROJECTION_YEAR, True)
push_to_supabase("player_projections", PROJECTION_YEAR, True)
push_to_supabase("game_projections", PROJECTION_YEAR, True)
push_to_supabase("last_update", PROJECTION_YEAR, True)