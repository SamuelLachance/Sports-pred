from model_training import *

goal_model = train_goal_model(projection_year=2025, retrain_model=True, verbose=True)